<?php
$module_name = 'B_Supplier';
$viewdefs [$module_name] = 
array (
  'EditView' => 
  array (
    'templateMeta' => 
    array (
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
      'syncDetailEditViews' => false,
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 'name',
          1 => 
          array (
            'name' => 'supplier_phone',
            'label' => 'LBL_SUPPLIER_PHONE',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'supplier_email',
            'label' => 'LBL_SUPPLIER_EMAIL',
          ),
          1 => 
          array (
            'name' => 'supplier_address',
            'label' => 'LBL_SUPPLIER_ADDRESS',
          ),
        ),
        2 => 
        array (
          0 => 'description',
          1 => '',
        ),
      ),
    ),
  ),
);
?>
