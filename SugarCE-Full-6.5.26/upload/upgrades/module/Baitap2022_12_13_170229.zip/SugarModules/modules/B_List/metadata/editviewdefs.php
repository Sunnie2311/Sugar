<?php
$module_name = 'B_List';
$viewdefs [$module_name] = 
array (
  'EditView' => 
  array (
    'templateMeta' => 
    array (
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'list_product',
            'studio' => 'visible',
            'label' => 'LBL_LIST_PRODUCT',
          ),
          1 => 
          array (
            'name' => 'list_product_quantity',
            'label' => 'LBL_LIST_PRODUCT_QUANTITY',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'b_list_b_product_name',
          ),
          1 => 'description',
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'b_list_b_receipt_name',
          ),
        ),
      ),
    ),
  ),
);
?>
