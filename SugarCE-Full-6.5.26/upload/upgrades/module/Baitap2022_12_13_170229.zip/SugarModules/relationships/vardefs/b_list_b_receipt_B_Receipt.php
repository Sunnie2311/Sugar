<?php
// created: 2022-12-13 17:02:28
$dictionary["B_Receipt"]["fields"]["b_list_b_receipt"] = array (
  'name' => 'b_list_b_receipt',
  'type' => 'link',
  'relationship' => 'b_list_b_receipt',
  'source' => 'non-db',
  'module' => 'B_List',
  'bean_name' => 'B_List',
  'side' => 'right',
  'vname' => 'LBL_B_LIST_B_RECEIPT_FROM_B_LIST_TITLE',
);
