<?php
// created: 2022-12-13 17:02:28
$dictionary["B_Supplier"]["fields"]["b_product_b_supplier"] = array (
  'name' => 'b_product_b_supplier',
  'type' => 'link',
  'relationship' => 'b_product_b_supplier',
  'source' => 'non-db',
  'module' => 'B_Product',
  'bean_name' => 'B_Product',
  'side' => 'right',
  'vname' => 'LBL_B_PRODUCT_B_SUPPLIER_FROM_B_PRODUCT_TITLE',
);
