<?php
// created: 2022-12-13 17:02:28
$dictionary["B_Customer"]["fields"]["b_receipt_b_customer"] = array (
  'name' => 'b_receipt_b_customer',
  'type' => 'link',
  'relationship' => 'b_receipt_b_customer',
  'source' => 'non-db',
  'module' => 'B_Receipt',
  'bean_name' => 'B_Receipt',
  'side' => 'right',
  'vname' => 'LBL_B_RECEIPT_B_CUSTOMER_FROM_B_RECEIPT_TITLE',
);
