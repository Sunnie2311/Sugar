<?php
// created: 2022-12-13 17:02:28
$dictionary["B_Product"]["fields"]["b_list_b_product"] = array (
  'name' => 'b_list_b_product',
  'type' => 'link',
  'relationship' => 'b_list_b_product',
  'source' => 'non-db',
  'module' => 'B_List',
  'bean_name' => 'B_List',
  'side' => 'right',
  'vname' => 'LBL_B_LIST_B_PRODUCT_FROM_B_LIST_TITLE',
);
