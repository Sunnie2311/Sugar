<?php
 // created: 2022-12-13 17:02:28
$layout_defs["B_Supplier"]["subpanel_setup"]['b_product_b_supplier'] = array (
  'order' => 100,
  'module' => 'B_Product',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_B_PRODUCT_B_SUPPLIER_FROM_B_PRODUCT_TITLE',
  'get_subpanel_data' => 'b_product_b_supplier',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
